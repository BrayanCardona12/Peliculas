package com.example.loginf2.screens

import android.util.Log
import androidx.compose.foundation.Image
import androidx.compose.foundation.background
import androidx.compose.foundation.border
import androidx.compose.foundation.clickable

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.text.ClickableText
import androidx.compose.material.*
import androidx.compose.runtime.Composable
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.res.painterResource
import androidx.compose.ui.res.stringResource
import androidx.compose.ui.text.SpanStyle
import androidx.compose.ui.text.TextStyle
import androidx.compose.ui.text.buildAnnotatedString
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.text.withStyle
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import androidx.navigation.NavController
import com.example.loginf2.R
import com.example.loginf2.models.MainViewModel
import com.example.loginf2.ui.theme.Shapes


@Composable
fun LoginScreen(
    isLoading: Boolean,
    siono: Boolean,
    onLoginClick: () -> Unit,
    MainviewModel: MainViewModel,
    navController: NavController
) {
    Column(
        modifier = Modifier
            .fillMaxSize()
            .background(MaterialTheme.colors.secondary),
        verticalArrangement = Arrangement.Center,
        horizontalAlignment = Alignment.CenterHorizontally
    ) {

        Text(
            text = "Cinema",
            modifier = Modifier
                .fillMaxWidth(),
            textAlign = TextAlign.Center,
            fontSize = MaterialTheme.typography.h1.fontSize,
            fontWeight = FontWeight.Bold,
            color = MaterialTheme.colors.primary
        )
        Image(
            painter = painterResource(R.drawable.cine),
            contentDescription = null,
            modifier = Modifier.width(300.dp)
        )

      //  val viewModel = MainViewModel()

        if (isLoading) {
            CircularProgressIndicator(modifier = Modifier.size(50.dp))
        } else {
            Text(
                text = "Ingresa con Google",
                textAlign = TextAlign.Center,
                style = TextStyle(fontSize = 30.sp),
                color = MaterialTheme.colors.primary,
                modifier = Modifier
                    .background(Color.Transparent)
                    .border(3.dp, MaterialTheme.colors.primary, Shapes.small)
                    .padding(all = 13.dp)
                    .clickable { onLoginClick() }
            )
            // Button( onClick = onLoginClick) {
            //   Text(stringResource(R.string.Login_cta))
            // }
        }


        // LegalText()
    }


}

@Composable
fun LegalText() {
    val anottatedString = buildAnnotatedString {
        append(stringResource(R.string.Text_Legal1))
        append(" ")
        pushStringAnnotation(tag = "URL", annotation = "app://terms")
        withStyle(
            style = SpanStyle(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colors.primary
            )
        ) {
            append(stringResource(R.string.Text_Legal2))
        }
        append(" ")
        pop()
        append(stringResource(R.string.Text_Legal3))
        append(" ")
        pushStringAnnotation(tag = "URL", annotation = "app://privacy")
        withStyle(
            style = SpanStyle(
                fontWeight = FontWeight.Bold,
                color = MaterialTheme.colors.primary
            )
        ) {
            append(stringResource(R.string.Text_Legal4))
        }
        pop()
    }
    Box(contentAlignment = Alignment.Center) {
        ClickableText(modifier = Modifier.padding(24.dp), text = anottatedString) { offset ->
            anottatedString.getStringAnnotations("URL", offset, offset)
                .firstOrNull()?.let { tag ->
                    Log.d("App", "Ha dado click en ${tag.item}")
                }
        }
    }
}