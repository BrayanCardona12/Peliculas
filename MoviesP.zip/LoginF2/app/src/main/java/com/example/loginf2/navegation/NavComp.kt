package com.example.loginf2.navegation

import androidx.compose.runtime.Composable
import androidx.compose.runtime.LaunchedEffect
import androidx.navigation.NavType

import androidx.navigation.compose.NavHost
import androidx.navigation.compose.composable
import androidx.navigation.compose.rememberNavController
import androidx.navigation.navArgument

import com.example.loginf2.screens.LoginScreen
import com.example.loginf2.models.MainViewModel
import com.example.loginf2.models.MoviesViewModel
import com.example.loginf2.screens.AddMovie
import com.example.loginf2.screens.Movie3
import com.example.loginf2.screens.Pant1

@Composable
fun Navegacion(
    isLoading: Boolean,
    siono: Boolean,
    onLoginClick: () -> Unit,
    MainviewModel: MainViewModel
) {
    val contr = rememberNavController()
    NavHost(navController = contr, startDestination = NavRoutes.Login.route) {

        // val viewModel = MainViewModel()
        composable(NavRoutes.Home.route) {
            Pant1(
                contr,
                algo = MainviewModel.state.value.algo,
                email = MainviewModel.state.value.nombre,
                img = MainviewModel.state.value.img,
                onLoginClick = onLoginClick,
                moviesViewModel = MoviesViewModel()
            )
        }

        composable(NavRoutes.Insertar.route) { AddMovie(contr) }

        composable(NavRoutes.Movie3.route, arguments = listOf(
            navArgument("foto") { type = NavType.StringType },
            navArgument("nombre") { type = NavType.StringType },
            navArgument("descripcion") { type = NavType.StringType }
        )) {
            Movie3(
                navController = contr,
                foto = it.arguments?.getString("foto") ?: "",
                nombre = it.arguments?.getString("nombre") ?: "",
                descripcion = it.arguments?.getString("descripcion") ?:""
            )
        }


        composable(NavRoutes.Login.route) {
            if (siono) {
                LaunchedEffect(key1 = Unit) {
                    contr.navigate(
                        NavRoutes.Home.route


                    ) {

                        popUpTo(NavRoutes.Login.route) {
                            inclusive = true
                        }

                    }
                }
            } else {
                LoginScreen(
                    isLoading,
                    siono,
                    onLoginClick,
                    MainviewModel,
                    contr
                )
            }
        }


    }
}