package com.example.loginf2.models

import androidx.compose.runtime.State
import androidx.compose.runtime.mutableStateOf
import androidx.lifecycle.ViewModel
import com.google.firebase.firestore.ktx.firestore
import com.google.firebase.firestore.ktx.toObjects
import com.google.firebase.ktx.Firebase



class MoviesViewModel: ViewModel() {
    private val _movies = mutableStateOf<List<Movies>>(emptyList())

    val movies : State<List<Movies>>
        get() = _movies
    private val query = Firebase.firestore.collection("movies")

    init {
        query.addSnapshotListener {
                value, _->
            if(value != null) {
                _movies.value = value.toObjects()
            } // fin del if
        } // fin del addSnapshotListener
    } // fin del contructor init
} // fin de la clase

// Funciopn tipo Unit