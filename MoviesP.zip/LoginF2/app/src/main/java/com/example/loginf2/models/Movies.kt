package com.example.loginf2.models

data class Movies(
    val img : String = "",
    val nombre:String = "",
    val fecha: String = "",
    val descripcion:String = ""

)