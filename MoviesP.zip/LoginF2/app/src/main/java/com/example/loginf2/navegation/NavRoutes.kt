package com.example.loginf2.navegation

import java.net.URLEncoder
import java.nio.charset.StandardCharsets

sealed class NavRoutes(val route: String) {
    object Home : NavRoutes("Pant1")
    object Regresar : NavRoutes("LoginScreen")

    object Movie3 : NavRoutes("Movie3/{foto}/{nombre}/{descripcion}") {
        fun createRoute(foto:String,nombre: String, descripcion: String, ): String {
            fun String.encodeUrl() = URLEncoder.encode(this, StandardCharsets.UTF_8.toString())
            return "Movie3/${foto.encodeUrl()}/$nombre/$descripcion"
        }
    }


    object HomeP : NavRoutes("Home2")



    object Login : NavRoutes("LoginScreen")
    object Insertar : NavRoutes("AddMovie")
}









